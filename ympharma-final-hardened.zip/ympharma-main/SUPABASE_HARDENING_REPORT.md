# Supabase Hardening Report

## Applied fixes
- Sanitized the example environment contract to separate browser-safe variables from server-only secrets.
- Added a storage mock fallback method (`createSignedUrl`) to the client-side Supabase fallback, preventing storage-driven runtime crashes when env vars are missing.
- Hardened the public-read server client to fail with a clearer server-only configuration message.
- Made the admin diagnostics anon client lazy/safe so missing preview envs no longer crash module evaluation.
- Switched the auth webhook to prefer server env for Supabase URL lookup.

## Files changed
- .env.example
- src/lib/supabase-public.server.ts
- src/integrations/supabase/client.ts
- src/routes/_authenticated/admin-diagnostics.tsx
- src/routes/lovable/email/auth/webhook.ts

## Notes
- This pass focuses on preventing runtime crashes and secret-surface confusion.
- A full codebase-wide remediation pass should still follow for server functions and domain contracts.
